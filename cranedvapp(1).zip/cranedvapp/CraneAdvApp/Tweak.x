#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"

#import "Common.h"
#import <Foundation/Foundation.h>
#import <Security/Security.h>
#import <UIKit/UIKit.h>
#import <sys/stat.h>

@interface ACAccount : NSObject
@property (nonatomic, copy) NSString *accountDescription;
@end

@interface ACAccountStore : NSObject
- (NSArray *)accountsWithAccountType:(id)type;
- (void)saveAccount:(ACAccount *)account withCompletionHandler:(void(^)(BOOL success, NSError *error))handler;
@end

static NSString *gBundleID = nil;
static NSString *gActiveContainer = @"default";
static NSString *gContainerRootDir = nil;
static NSString *gIsolatedSuiteName = nil;
static BOOL gIsDefaultContainer = YES; // 是否处于默认原生容器

static BOOL gProtectContainers = NO;
static BOOL gPreventSandboxLookup = NO;
static BOOL gSeparateAccounts = NO;
static BOOL gSeparateNotifications = NO;

static void SetupContainerStorage(void) {
    gBundleID = [[NSBundle mainBundle] bundleIdentifier];
    if (!gBundleID || [gBundleID hasPrefix:@"com.apple."]) return;

    gActiveContainer = CraneActiveContainerForBundle(gBundleID);
    gIsDefaultContainer = [gActiveContainer isEqualToString:@"default"];

    // 核心修复：如果处于默认容器，直接使用系统原生路径，坚决不进行重定向与破坏！
    if (gIsDefaultContainer) {
        gContainerRootDir = nil;
        gIsolatedSuiteName = nil;
        return;
    }

    // 仅针对非 default 的独立分身建立隔离目录
    gIsolatedSuiteName = [NSString stringWithFormat:@"%@.crane.%@", gBundleID, gActiveContainer];
    gProtectContainers = CraneGetAppBool(gBundleID, @"ContainerProtection", NO);
    gPreventSandboxLookup = CraneGetAppBool(gBundleID, @"PreventSandboxLookup", NO);
    gSeparateAccounts = CraneGetAppBool(gBundleID, @"SeparateAccounts", NO);
    gSeparateNotifications = CraneGetAppBool(gBundleID, @"SeparateNotifications", NO);

    NSString *home = NSHomeDirectory();
    gContainerRootDir = [home stringByAppendingPathComponent:[NSString stringWithFormat:@"_CraneContainers/%@", gActiveContainer]];

    NSFileManager *fm = [NSFileManager defaultManager];
    [fm createDirectoryAtPath:[gContainerRootDir stringByAppendingPathComponent:@"Documents"] withIntermediateDirectories:YES attributes:nil error:nil];
    [fm createDirectoryAtPath:[gContainerRootDir stringByAppendingPathComponent:@"Library/Caches"] withIntermediateDirectories:YES attributes:nil error:nil];
    [fm createDirectoryAtPath:[gContainerRootDir stringByAppendingPathComponent:@"Library/Preferences"] withIntermediateDirectories:YES attributes:nil error:nil];
    [fm createDirectoryAtPath:[gContainerRootDir stringByAppendingPathComponent:@"tmp"] withIntermediateDirectories:YES attributes:nil error:nil];
}

// 1. 基础沙盒路径重定向（仅对非 default 容器生效）
%hookf(NSArray<NSString *> *, NSSearchPathForDirectoriesInDomains, NSSearchPathDirectory directory, NSSearchPathDomainMask domainMask, BOOL expandTilde) {
    if (gIsDefaultContainer || !gContainerRootDir || domainMask != NSUserDomainMask) {
        return %orig;
    }
    switch (directory) {
        case NSDocumentDirectory:
            return @[[gContainerRootDir stringByAppendingPathComponent:@"Documents"]];
        case NSLibraryDirectory:
            return @[[gContainerRootDir stringByAppendingPathComponent:@"Library"]];
        case NSCachesDirectory:
            return @[[gContainerRootDir stringByAppendingPathComponent:@"Library/Caches"]];
        default:
            return %orig;
    }
}

// 2. 防止沙盒查找 (Prevent Sandbox Lookup)：修复 WebKit Cookie 无法持久化问题
%hookf(char *, realpath, const char *path, char *resolved_path) {
    char *res = %orig(path, resolved_path);
    if (!gIsDefaultContainer && gPreventSandboxLookup && res && gContainerRootDir) {
        NSString *strRes = [NSString stringWithUTF8String:res];
        NSString *rawHome = NSHomeDirectory();
        if ([strRes hasPrefix:rawHome] && ![strRes containsString:@"_CraneContainers"]) {
            NSString *fakePath = [strRes stringByReplacingOccurrencesOfString:rawHome withString:gContainerRootDir];
            if (resolved_path) {
                strncpy(resolved_path, [fakePath UTF8String], PATH_MAX);
                return resolved_path;
            }
        }
    }
    return res;
}

// 3. 容器保护 (Container Protection)：防止 App 扫描或清空其他容器的数据
%hook NSFileManager

- (NSArray<NSString *> *)contentsOfDirectoryAtPath:(NSString *)path error:(NSError **)error {
    NSArray<NSString *> *contents = %orig;
    // 隐藏 _CraneContainers 目录，让应用以为自己处于纯净的原生环境
    if (gProtectContainers && contents && [path isEqualToString:NSHomeDirectory()]) {
        NSMutableArray *filtered = [contents mutableCopy];
        [filtered removeObject:@"_CraneContainers"];
        return filtered;
    }
    return contents;
}

- (BOOL)removeItemAtPath:(NSString *)path error:(NSError **)error {
    if (gProtectContainers && [path containsString:@"_CraneContainers"]) {
        // 如果 App 试图清理非本容器的数据，直接阻断
        if (gIsDefaultContainer || (gContainerRootDir && ![path hasPrefix:gContainerRootDir])) {
            return YES; // 伪装成功，防止 App 抛异常崩溃
        }
    }
    return %orig;
}

- (BOOL)removeItemAtURL:(NSURL *)URL error:(NSError **)error {
    return [self removeItemAtPath:[URL path] error:error];
}

%end

// 4. NSUserDefaults 隔离（仅在分身状态下启用隔离 Suite）
%hook NSUserDefaults

- (id)init {
    if (!gIsDefaultContainer && gIsolatedSuiteName) {
        return [self initWithSuiteName:gIsolatedSuiteName];
    }
    return %orig;
}

- (id)initWithSuiteName:(NSString *)suitename {
    if (!suitename && !gIsDefaultContainer && gIsolatedSuiteName) {
        return %orig(gIsolatedSuiteName);
    }
    return %orig;
}

%end

// 5. Keychain 数据隔离（默认容器使用原生 Keychain，分身容器使用带前缀的独立 Keychain）
static NSMutableDictionary *ModifyKeychainQuery(NSDictionary *orig) {
    if (gIsDefaultContainer || !orig || !gActiveContainer) return [orig mutableCopy];
    NSMutableDictionary *mod = [orig mutableCopy];
    NSString *tag = [NSString stringWithFormat:@"CR_%@_", gActiveContainer];

    id service = mod[(__bridge id)kSecAttrService];
    if ([service isKindOfClass:[NSString class]] && ![service hasPrefix:tag]) {
        mod[(__bridge id)kSecAttrService] = [tag stringByAppendingString:service];
    }
    id account = mod[(__bridge id)kSecAttrAccount];
    if ([account isKindOfClass:[NSString class]] && ![account hasPrefix:tag]) {
        mod[(__bridge id)kSecAttrAccount] = [tag stringByAppendingString:account];
    }
    return mod;
}

%hookf(OSStatus, SecItemAdd, CFDictionaryRef attributes, CFTypeRef *result) {
    return %orig((__bridge CFDictionaryRef)ModifyKeychainQuery((__bridge NSDictionary *)attributes), result);
}
%hookf(OSStatus, SecItemCopyMatching, CFDictionaryRef query, CFTypeRef *result) {
    return %orig((__bridge CFDictionaryRef)ModifyKeychainQuery((__bridge NSDictionary *)query), result);
}
%hookf(OSStatus, SecItemUpdate, CFDictionaryRef query, CFDictionaryRef attributesToUpdate) {
    return %orig((__bridge CFDictionaryRef)ModifyKeychainQuery((__bridge NSDictionary *)query), attributesToUpdate);
}
%hookf(OSStatus, SecItemDelete, CFDictionaryRef query) {
    return %orig((__bridge CFDictionaryRef)ModifyKeychainQuery((__bridge NSDictionary *)query));
}

// 6. 独立的系统帐户 (Separate Accounts)：为每个分身隔离 Apple ID/Game Center 等账户
%hook ACAccountStore

- (NSArray *)accountsWithAccountType:(id)type {
    NSArray *orig = %orig;
    if (gIsDefaultContainer || !gSeparateAccounts || !orig) return orig;

    NSString *containerTag = [NSString stringWithFormat:@"[Crane:%@]", gActiveContainer];
    NSMutableArray *matched = [NSMutableArray array];
    for (ACAccount *acc in orig) {
        if ([acc.accountDescription containsString:containerTag]) {
            [matched addObject:acc];
        }
    }
    return matched;
}

- (void)saveAccount:(ACAccount *)account withCompletionHandler:(void(^)(BOOL success, NSError *error))handler {
    if (!gIsDefaultContainer && gSeparateAccounts) {
        NSString *tag = [NSString stringWithFormat:@"[Crane:%@]", gActiveContainer];
        if (![account.accountDescription containsString:tag]) {
            account.accountDescription = [NSString stringWithFormat:@"%@ %@", account.accountDescription ?: @"", tag];
        }
    }
    %orig(account, handler);
}

%end

// 7. 单独的通知注册 (Separate Notifications)
%hook UIApplication

- (void)registerForRemoteNotifications {
    if (!gIsDefaultContainer && gSeparateNotifications) {
        [[NSUserDefaults standardUserDefaults] setObject:gActiveContainer forKey:@"CraneNotificationContainerIdentity"];
    }
    %orig;
}

%end

%ctor {
    @autoreleasepool {
        if (!CraneIsEnabled()) return;
        SetupContainerStorage();
        %init;
    }
}

#pragma clang diagnostic pop
