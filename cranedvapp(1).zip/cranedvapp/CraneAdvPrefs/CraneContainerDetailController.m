#import "CraneContainerDetailController.h"
#import "../Common.h"
#import <Preferences/PSSpecifier.h>
#import <objc/runtime.h>
#import <notify.h>
#import <spawn.h>

extern char **environ;

@interface LSApplicationProxy : NSObject
+ (instancetype)applicationProxyForIdentifier:(NSString *)bundleID;
- (NSURL *)dataContainerURL;
- (NSURL *)bundleURL;
@end

@interface CraneContainerDetailController ()
@property (nonatomic, copy) NSString *bundleID;
@property (nonatomic, copy) NSString *containerID;
@end

@implementation CraneContainerDetailController

static void KillAppProcess(NSString *bundleID) {
    if (!bundleID) return;
    LSApplicationProxy *proxy = [objc_getClass("LSApplicationProxy") applicationProxyForIdentifier:bundleID];
    NSString *execName = [[proxy bundleURL] lastPathComponent].stringByDeletingPathExtension;
    if (!execName || execName.length == 0) execName = bundleID.lastPathComponent;

    pid_t pid;
    const char *execCStr = [execName UTF8String];
    const char *args[] = {"killall", "-9", execCStr, NULL};
    if (posix_spawn(&pid, "/var/jb/usr/bin/killall", NULL, NULL, (char *const *)args, environ) != 0) {
        posix_spawn(&pid, "/usr/bin/killall", NULL, NULL, (char *const *)args, environ);
    }
}

static BOOL DeleteContainerPhysicalDirectory(NSString *bundleID, NSString *containerID, NSError **outError) {
    if (!bundleID || !containerID || [containerID isEqualToString:@"default"]) return NO;
    LSApplicationProxy *proxy = [objc_getClass("LSApplicationProxy") applicationProxyForIdentifier:bundleID];
    NSURL *containerDataURL = [proxy dataContainerURL];
    if (!containerDataURL) return NO;

    NSString *targetPath = [[containerDataURL path] stringByAppendingPathComponent:[NSString stringWithFormat:@"_CraneContainers/%@", containerID]];
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:targetPath]) {
        return [fm removeItemAtPath:targetPath error:outError];
    }
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.bundleID = [self.specifier propertyForKey:@"bundleID"];
    self.containerID = [self.specifier propertyForKey:@"containerID"];
    self.title = [self.containerID isEqualToString:@"default"] ? @"默认" : self.containerID;
}

- (NSArray *)specifiers {
    NSMutableArray *specs = [NSMutableArray array];

    PSSpecifier *g1 = [PSSpecifier groupSpecifierWithName:@"桌面快捷方式"];
    [specs addObject:g1];

    PSSpecifier *pinSpec = [PSSpecifier preferenceSpecifierNamed:@"添加到主屏幕 (生成独立分身)"
                                                          target:self
                                                             set:NULL
                                                             get:NULL
                                                          detail:Nil
                                                            cell:PSButtonCell
                                                            edit:Nil];
    pinSpec->action = @selector(pinToHomeScreen);
    [specs addObject:pinSpec];

    PSSpecifier *g2 = [PSSpecifier groupSpecifierWithName:@"容器状态"];
    [specs addObject:g2];

    BOOL isActive = [self.containerID isEqualToString:CraneActiveContainerForBundle(self.bundleID)];
    NSString *switchTitle = isActive ? @"当前容器已激活 ✓" : @"切换激活为此容器";
    PSSpecifier *switchSpec = [PSSpecifier preferenceSpecifierNamed:switchTitle
                                                             target:self
                                                                set:NULL
                                                                get:NULL
                                                             detail:Nil
                                                               cell:PSButtonCell
                                                               edit:Nil];
    switchSpec->action = @selector(makeActive);
    [specs addObject:switchSpec];

    PSSpecifier *g3 = [PSSpecifier groupSpecifierWithName:@"数据清理"];
    [specs addObject:g3];

    PSSpecifier *delSpec = [PSSpecifier preferenceSpecifierNamed:@"删除此容器"
                                                          target:self
                                                             set:NULL
                                                             get:NULL
                                                          detail:Nil
                                                            cell:PSButtonCell
                                                            edit:Nil];
    delSpec->action = @selector(deleteContainerPrompt);
    [specs addObject:delSpec];

    _specifiers = specs;
    return _specifiers;
}

- (void)pinToHomeScreen {
    NSMutableDictionary *prefs = CraneLoadAllPrefs();
    prefs[@"PendingClipBundleID"] = self.bundleID;
    prefs[@"PendingClipContainerID"] = self.containerID;
    CraneSaveAllPrefs(prefs);

    notify_post(NOTIFY_CREATE_CLIP);

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"已发送指令"
                                                                   message:@"SpringBoard 正在主屏幕生成独立图标，返回桌面即可查看。"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)makeActive {
    CraneSetActiveContainerForBundle(self.bundleID, self.containerID);
    KillAppProcess(self.bundleID);
    [self reloadSpecifiers];
}

- (void)deleteContainerPrompt {
    if ([self.containerID isEqualToString:@"default"]) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"默认容器 (default) 无法被删除" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"删除容器确认"
                                                                   message:[NSString stringWithFormat:@"即将移除分身 [%@]。是否同时清空该容器在沙盒中的物理存储数据？", self.containerID]
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    [alert addAction:[UIAlertAction actionWithTitle:@"彻底删除并清空沙盒数据" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [self executeDeleteWithPurge:YES];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:@"仅解除绑定 (保留数据)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self executeDeleteWithPurge:NO];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)executeDeleteWithPurge:(BOOL)purge {
    KillAppProcess(self.bundleID);

    if (purge) {
        NSError *err = nil;
        DeleteContainerPhysicalDirectory(self.bundleID, self.containerID, &err);
    }

    NSMutableDictionary *prefs = CraneLoadAllPrefs();
    NSString *key = [NSString stringWithFormat:@"Containers_%@", self.bundleID];
    NSMutableArray *list = [prefs[key] mutableCopy] ?: [NSMutableArray array];
    [list removeObject:self.containerID];
    prefs[key] = list;

    if ([CraneActiveContainerForBundle(self.bundleID) isEqualToString:self.containerID]) {
        prefs[self.bundleID] = @"default";
    }
    CraneSaveAllPrefs(prefs);

    [self.navigationController popViewControllerAnimated:YES];
}

@end
