#import "CraneRootListController.h"
#import <spawn.h>

extern char **environ;

@implementation CraneRootListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

- (void)respring:(id)sender {
    pid_t pid;
    const char *args[] = {"sbreload", NULL};
    if (posix_spawn(&pid, "/var/jb/usr/bin/sbreload", NULL, NULL, (char *const *)args, environ) != 0) {
        posix_spawn(&pid, "/usr/bin/sbreload", NULL, NULL, (char *const *)args, environ);
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        pid_t killPid;
        const char *killArgs[] = {"killall", "-9", "SpringBoard", NULL};
        if (posix_spawn(&killPid, "/var/jb/usr/bin/killall", NULL, NULL, (char *const *)killArgs, environ) != 0) {
            posix_spawn(&killPid, "/usr/bin/killall", NULL, NULL, (char *const *)killArgs, environ);
        }
    });
}

@end
