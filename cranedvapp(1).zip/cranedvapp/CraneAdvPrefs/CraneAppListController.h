#import <Preferences/PSListController.h>

@interface CraneAppListController : PSListController
@end
