#import <Preferences/PSListController.h>

@interface CraneContainerDetailController : PSListController
@end
