#import <Preferences/PSListController.h>

@interface CraneAppDetailController : PSListController
@end
