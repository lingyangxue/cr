#import <Preferences/PSListController.h>

@interface CraneRootListController : PSListController
@end
