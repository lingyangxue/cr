#import "CraneAppDetailController.h"
#import "CraneContainerDetailController.h"
#import "../Common.h"
#import <Preferences/PSSpecifier.h>
#import <notify.h>

@interface CraneAppDetailController ()
@property (nonatomic, copy) NSString *bundleID;
@property (nonatomic, copy) NSString *appName;
@property (nonatomic, strong) NSMutableArray<NSString *> *containers;
@end

@implementation CraneAppDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.bundleID = [self.specifier propertyForKey:@"bundleID"];
    self.appName = [self.specifier propertyForKey:@"appName"];
    self.title = self.appName ?: @"容器管理";
}

- (void)loadContainers {
    self.containers = [CraneGetContainersForBundle(self.bundleID) mutableCopy];
}

- (NSArray *)specifiers {
    [self loadContainers];
    NSMutableArray *specs = [NSMutableArray array];

    // 1. 在程序启动时始终询问
    PSSpecifier *group1 = [PSSpecifier groupSpecifierWithName:@""];
    [specs addObject:group1];

    PSSpecifier *askSpec = [PSSpecifier preferenceSpecifierNamed:@"在程序启动时始终询问"
                                                          target:self
                                                             set:@selector(setPreferenceValue:specifier:)
                                                             get:@selector(readPreferenceValue:)
                                                          detail:Nil
                                                            cell:PSSwitchCell
                                                            edit:Nil];
    [askSpec setProperty:@"PromptOnLaunch" forKey:@"key"];
    [specs addObject:askSpec];

    // 2. 容器 (分身) 列表
    PSSpecifier *group2 = [PSSpecifier groupSpecifierWithName:@"容器 (分身)"];
    [specs addObject:group2];

    for (NSString *cID in self.containers) {
        PSSpecifier *cSpec = [PSSpecifier preferenceSpecifierNamed:[cID isEqualToString:@"default"] ? @"默认" : cID
                                                            target:self
                                                               set:NULL
                                                               get:NULL
                                                            detail:[CraneContainerDetailController class]
                                                              cell:PSLinkCell
                                                              edit:Nil];
        [cSpec setProperty:self.bundleID forKey:@"bundleID"];
        [cSpec setProperty:cID forKey:@"containerID"];
        [specs addObject:cSpec];
    }

    PSSpecifier *addSpec = [PSSpecifier preferenceSpecifierNamed:@"新增"
                                                          target:self
                                                             set:NULL
                                                             get:NULL
                                                          detail:Nil
                                                            cell:PSButtonCell
                                                            edit:Nil];
    addSpec->action = @selector(addNewContainerPrompt);
    [specs addObject:addSpec];

    // 3. 桌面分身独立图标生成功能区
    PSSpecifier *groupPin = [PSSpecifier groupSpecifierWithName:@"桌面快捷方式"];
    [groupPin setProperty:@"点击下方按钮，直接在主屏幕生成当前激活容器的独立图标。" forKey:@"footerText"];
    [specs addObject:groupPin];

    NSString *activeC = CraneActiveContainerForBundle(self.bundleID);
    PSSpecifier *createClipSpec = [PSSpecifier preferenceSpecifierNamed:[NSString stringWithFormat:@"生成 [%@] 的主屏幕分身图标", activeC]
                                                                 target:self
                                                                    set:NULL
                                                                    get:NULL
                                                                 detail:Nil
                                                                   cell:PSButtonCell
                                                                   edit:Nil];
    createClipSpec->action = @selector(createCurrentContainerIcon);
    [specs addObject:createClipSpec];

    // 4. 单独的通知注册
    PSSpecifier *group3 = [PSSpecifier groupSpecifierWithName:@""];
    [group3 setProperty:@"启用此开关后，此应用程序的每个 Crane 容器都将获得一个单独的通知令牌，该令牌会启用来自所有容器的传入通知。当点击收到的通知时，应用程序将启动到通知来源的容器中。此外，还可单独设置每个容器是否允许通知。\n(注意：这不适用于所有应用程序，某些应用程序甚至会在未启用此开关的情况下获得所有容器的通知。)" forKey:@"footerText"];
    [specs addObject:group3];

    PSSpecifier *notifSpec = [PSSpecifier preferenceSpecifierNamed:@"单独的通知注册"
                                                            target:self
                                                               set:@selector(setPreferenceValue:specifier:)
                                                               get:@selector(readPreferenceValue:)
                                                            detail:Nil
                                                              cell:PSSwitchCell
                                                              edit:Nil];
    [notifSpec setProperty:@"SeparateNotifications" forKey:@"key"];
    [specs addObject:notifSpec];

    // 5. 独立的系统帐户
    PSSpecifier *group4 = [PSSpecifier groupSpecifierWithName:@""];
    [group4 setProperty:@"是否重定向每个容器的应用程序访问的系统帐户 (例如 Apple ID)，主要用于 AppStore 等系统应用程序。\n\n\"游戏中心支持\"必须单独启用，并要求在其设置中手动将游戏中心帐户分配给容器。" forKey:@"footerText"];
    [specs addObject:group4];

    PSSpecifier *accSpec = [PSSpecifier preferenceSpecifierNamed:@"独立的系统帐户"
                                                          target:self
                                                             set:@selector(setPreferenceValue:specifier:)
                                                             get:@selector(readPreferenceValue:)
                                                            detail:Nil
                                                              cell:PSSwitchCell
                                                              edit:Nil];
    [accSpec setProperty:@"SeparateAccounts" forKey:@"key"];
    [specs addObject:accSpec];

    // 6. 容器保护
    PSSpecifier *group5 = [PSSpecifier groupSpecifierWithName:@""];
    [group5 setProperty:@"防止应用程序在启动到某些应用程序所需的默认容器时删除其他容器的数据。使用应用程序钩子。" forKey:@"footerText"];
    [specs addObject:group5];

    PSSpecifier *protectSpec = [PSSpecifier preferenceSpecifierNamed:@"容器保护"
                                                              target:self
                                                                 set:@selector(setPreferenceValue:specifier:)
                                                                 get:@selector(readPreferenceValue:)
                                                              detail:Nil
                                                                cell:PSSwitchCell
                                                                edit:Nil];
    [protectSpec setProperty:@"ContainerProtection" forKey:@"key"];
    [specs addObject:protectSpec];

    // 7. 防止沙盒查找
    PSSpecifier *group6 = [PSSpecifier groupSpecifierWithName:@""];
    [group6 setProperty:@"防止应用程序对其自身进行沙盒查找以接收真正的非重定向路径。修复了 Web 浏览器无法将 cookie 保存在非默认容器中的问题。使用应用程序钩子。" forKey:@"footerText"];
    [specs addObject:group6];

    PSSpecifier *sandboxSpec = [PSSpecifier preferenceSpecifierNamed:@"防止沙盒查找"
                                                              target:self
                                                                 set:@selector(setPreferenceValue:specifier:)
                                                                 get:@selector(readPreferenceValue:)
                                                              detail:Nil
                                                                cell:PSSwitchCell
                                                                edit:Nil];
    [sandboxSpec setProperty:@"PreventSandboxLookup" forKey:@"key"];
    [specs addObject:sandboxSpec];

    _specifiers = specs;
    return _specifiers;
}

- (id)readPreferenceValue:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    return @(CraneGetAppBool(self.bundleID, key, NO));
}

- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    CraneSetAppBool(self.bundleID, key, [value boolValue]);
}

- (void)createCurrentContainerIcon {
    NSString *currentContainer = CraneActiveContainerForBundle(self.bundleID);
    NSMutableDictionary *prefs = CraneLoadAllPrefs();
    prefs[@"PendingClipBundleID"] = self.bundleID;
    prefs[@"PendingClipContainerID"] = currentContainer;
    CraneSaveAllPrefs(prefs);

    notify_post(NOTIFY_CREATE_CLIP);

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"正在生成分身"
                                                                   message:[NSString stringWithFormat:@"已向 SpringBoard 发送指令，返回桌面即可查看 [%@] 容器的独立图标！", currentContainer]
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)addNewContainerPrompt {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"新增容器" message:@"请输入新容器标识：" preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *tf) { tf.placeholder = @"例如：work / user2"; }];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *name = [alert.textFields.firstObject.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (name.length > 0 && ![self.containers containsObject:name]) {
            [self.containers addObject:name];
            NSMutableDictionary *prefs = CraneLoadAllPrefs();
            NSString *listKey = [NSString stringWithFormat:@"Containers_%@", self.bundleID];
            prefs[listKey] = self.containers;
            CraneSaveAllPrefs(prefs);
            [self reloadSpecifiers];
        }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
