#import "CraneAppListController.h"
#import "CraneAppDetailController.h"
#import <Preferences/PSSpecifier.h>
#import <objc/runtime.h>

@interface LSApplicationProxy : NSObject
@property (nonatomic, readonly) NSString *bundleIdentifier;
@property (nonatomic, readonly) NSString *localizedName;
@property (nonatomic, readonly) NSString *applicationType;
- (NSData *)iconDataForVariant:(int)variant;
@end

@interface LSApplicationWorkspace : NSObject
+ (instancetype)defaultWorkspace;
- (NSArray<LSApplicationProxy *> *)allInstalledApplications;
@end

@implementation CraneAppListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *specs = [NSMutableArray array];
        
        PSSpecifier *groupSpec = [PSSpecifier groupSpecifierWithName:@"已安装应用"];
        [specs addObject:groupSpec];

        LSApplicationWorkspace *workspace = [objc_getClass("LSApplicationWorkspace") defaultWorkspace];
        NSArray<LSApplicationProxy *> *apps = [workspace allInstalledApplications];

        NSMutableArray<LSApplicationProxy *> *userApps = [NSMutableArray array];
        for (LSApplicationProxy *app in apps) {
            // 过滤系统核心守护进程，只展示带有效显示名称和 Bundle ID 的三方/用户应用
            if ([app.applicationType isEqualToString:@"User"] && app.bundleIdentifier && app.localizedName) {
                [userApps addObject:app];
            }
        }

        // 按应用名称拼音首字母排序
        [userApps sortUsingComparator:^NSComparisonResult(LSApplicationProxy *a, LSApplicationProxy *b) {
            return [a.localizedName localizedStandardCompare:b.localizedName];
        }];

        // 为每个应用生成指向 CraneAppDetailController 的跳转 Specifier
        for (LSApplicationProxy *app in userApps) {
            PSSpecifier *spec = [PSSpecifier preferenceSpecifierNamed:app.localizedName
                                                              target:self
                                                                 set:NULL
                                                                 get:NULL
                                                              detail:[CraneAppDetailController class]
                                                                cell:PSLinkCell
                                                                edit:Nil];
            [spec setProperty:app.bundleIdentifier forKey:@"bundleID"];
            [spec setProperty:app.localizedName forKey:@"appName"];
            [specs addObject:spec];
        }

        _specifiers = specs;
    }
    return _specifiers;
}

@end
