#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"

#import "Common.h"
#import <UIKit/UIKit.h>
#import <notify.h>
#import <dlfcn.h>
#import <objc/runtime.h>

@interface SBSApplicationShortcutItem : NSObject
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *localizedTitle;
@property (nonatomic, copy) NSString *localizedSubtitle;
@end

@interface SBApplicationShortcutStore : NSObject
- (NSString *)bundleIdentifier;
- (NSArray<SBSApplicationShortcutItem *> *)shortcutItems;
@end

@interface FBProcess : NSObject
- (void)killForReason:(NSInteger)reason andReport:(BOOL)report withDescription:(NSString *)desc completion:(id)completion;
@end

@interface FBProcessManager : NSObject
+ (instancetype)sharedInstance;
- (NSArray<FBProcess *> *)processesForBundleIdentifier:(NSString *)bundleID;
@end

@interface LSApplicationProxy : NSObject
+ (instancetype)applicationProxyForIdentifier:(NSString *)bundleID;
- (NSString *)localizedName;
- (NSData *)iconDataForVariant:(int)variant;
@end

@interface UIWebClip : NSObject
+ (instancetype)webClipWithIdentifier:(NSString *)identifier;
- (instancetype)initWithIdentifier:(NSString *)identifier;
- (void)setTitle:(NSString *)title;
- (void)setPageURL:(NSURL *)pageURL;
- (void)setFullScreen:(BOOL)fullscreen;
- (void)setClassicMode:(BOOL)classic;
- (void)setIconImage:(UIImage *)image isPrecomposed:(BOOL)precomposed;
- (BOOL)save;
- (NSURL *)pageURL;
@end

@interface SBApplication : NSObject
- (NSString *)bundleIdentifier;
@end

@interface SBApplicationController : NSObject
+ (instancetype)sharedInstance;
- (SBApplication *)applicationWithBundleIdentifier:(NSString *)bundleIdentifier;
@end

@interface SBUIController : NSObject
+ (instancetype)sharedInstance;
- (void)activateApplication:(SBApplication *)app;
@end

@interface SBAlertItem : NSObject
- (void)deactivate;
- (UIAlertController *)alertController;
- (void)setAlertController:(UIAlertController *)alertController;
@end

@interface SBAlertItemsController : NSObject
+ (instancetype)sharedInstance;
- (void)activateAlertItem:(id)item;
@end

// 声明动态类接口供编译器检查，不声明 @implementation 避免触发静态链接错误
@interface CraneLaunchPromptAlertItem : SBAlertItem
@property (nonatomic, copy) NSString *targetBundleID;
@property (nonatomic, strong) NSArray *targetContainers;
@end

static void KillProcess(NSString *bundleID) {
    if (!bundleID) return;
    FBProcessManager *pm = [%c(FBProcessManager) sharedInstance];
    NSArray *procs = [pm processesForBundleIdentifier:bundleID];
    for (FBProcess *proc in procs) {
        if ([proc respondsToSelector:@selector(killForReason:andReport:withDescription:completion:)]) {
            [proc killForReason:1 andReport:NO withDescription:@"Crane Switch Container" completion:nil];
        }
    }
}

static void LaunchTargetApp(NSString *bundleID) {
    SBApplicationController *appCtrl = [%c(SBApplicationController) sharedInstance];
    SBApplication *app = [appCtrl applicationWithBundleIdentifier:bundleID];
    if (app) {
        SBUIController *uiCtrl = [%c(SBUIController) sharedInstance];
        [uiCtrl activateApplication:app];
    }
}

static UIImage *CraneExtractHDAppIcon(NSString *bundleID) {
    CGFloat scale = [UIScreen mainScreen].scale;
    LSApplicationProxy *proxy = [objc_getClass("LSApplicationProxy") applicationProxyForIdentifier:bundleID];
    if (proxy) {
        NSData *iconData = [proxy iconDataForVariant:2];
        if (iconData) {
            return [UIImage imageWithData:iconData scale:scale];
        }
    }
    return nil;
}

static void CleanCorruptedWebClips(void) {
    NSString *baseDir = @"/var/mobile/Library/WebClips";
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *items = [fm contentsOfDirectoryAtPath:baseDir error:nil];
    for (NSString *item in items) {
        if ([item hasSuffix:@".webclip"]) {
            NSString *folder = [baseDir stringByAppendingPathComponent:item];
            NSString *infoFile = [folder stringByAppendingPathComponent:@"Info.plist"];
            if (![fm fileExistsAtPath:infoFile]) {
                [fm removeItemAtPath:folder error:nil];
            }
        }
    }
}

static void CreateDesktopIconForContainer(NSString *bundleID, NSString *containerID) {
    if (!bundleID || !containerID) return;

    dlopen("/System/Library/PrivateFrameworks/WebClip.framework/WebClip", RTLD_NOW);

    NSString *clipUUID = [[NSUUID UUID] UUIDString];
    NSString *launchURL = [NSString stringWithFormat:@"%@://open?bundleID=%@&container=%@", CRANE_SCHEME, bundleID, containerID];
    
    LSApplicationProxy *appProxy = [objc_getClass("LSApplicationProxy") applicationProxyForIdentifier:bundleID];
    NSString *appName = [appProxy localizedName] ?: bundleID.lastPathComponent;
    NSString *displayTitle = [NSString stringWithFormat:@"%@ (%@)", appName, containerID];
    UIImage *appIcon = CraneExtractHDAppIcon(bundleID);

    NSString *clipDir = [NSString stringWithFormat:@"/var/mobile/Library/WebClips/%@.webclip", clipUUID];
    NSFileManager *fm = [NSFileManager defaultManager];
    [fm createDirectoryAtPath:clipDir withIntermediateDirectories:YES attributes:nil error:nil];

    NSDictionary *clipMeta = @{
        @"Identifier": clipUUID,
        @"ApplicationBundleID": @"",
        @"ClassicMode": @NO,
        @"FullScreen": @YES,
        @"IconIsPrecomposed": @YES,
        @"IconIsScreenShotBased": @NO,
        @"IsWebClip": @YES,
        @"Title": displayTitle,
        @"URL": launchURL,
        @"UIStatusBarStyle": @"UIStatusBarStyleDefault"
    };
    NSString *plistPath = [clipDir stringByAppendingPathComponent:@"Info.plist"];
    [clipMeta writeToFile:plistPath atomically:YES];
    chmod([plistPath UTF8String], 0666);

    if (appIcon) {
        NSData *pngData = UIImagePNGRepresentation(appIcon);
        if (pngData) {
            NSString *iconPath = [clipDir stringByAppendingPathComponent:@"icon.png"];
            [pngData writeToFile:iconPath atomically:YES];
            chmod([iconPath UTF8String], 0666);
        }
    }
    chmod([clipDir UTF8String], 0777);

    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(), CFSTR("com.apple.webclips.changed"), NULL, NULL, YES);
}

static void HandleClipCreationRequest(void) {
    NSDictionary *prefs = CraneLoadAllPrefs();
    NSString *bundleID = prefs[@"PendingClipBundleID"];
    NSString *containerID = prefs[@"PendingClipContainerID"];

    if (bundleID && containerID) {
        CreateDesktopIconForContainer(bundleID, containerID);
        NSMutableDictionary *mut = [prefs mutableCopy];
        [mut removeObjectForKey:@"PendingClipBundleID"];
        [mut removeObjectForKey:@"PendingClipContainerID"];
        CraneSaveAllPrefs(mut);
    }
}

static BOOL gIsBypassingPrompt = NO;

// 使用 Logos %subclass 在运行时动态注册子类，杜绝编译期未定义符号错误
%subclass CraneLaunchPromptAlertItem : SBAlertItem

%property (nonatomic, copy) NSString *targetBundleID;
%property (nonatomic, strong) NSArray *targetContainers;

- (void)configure:(BOOL)configure requirePasscodeForActions:(BOOL)require {
    UIAlertController *alert = [self alertController];
    if (!alert) {
        alert = [UIAlertController alertControllerWithTitle:@"选择启动容器"
                                                    message:[NSString stringWithFormat:@"目标应用: %@", [self.targetBundleID lastPathComponent]]
                                             preferredStyle:UIAlertControllerStyleActionSheet];
        if ([self respondsToSelector:@selector(setAlertController:)]) {
            [self setAlertController:alert];
        }
    } else {
        alert.title = @"选择启动容器";
        alert.message = [NSString stringWithFormat:@"目标应用: %@", [self.targetBundleID lastPathComponent]];
    }

    for (NSString *cID in self.targetContainers) {
        [alert addAction:[UIAlertAction actionWithTitle:cID style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            CraneSetActiveContainerForBundle(self.targetBundleID, cID);
            KillProcess(self.targetBundleID);

            gIsBypassingPrompt = YES;
            LaunchTargetApp(self.targetBundleID);
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                gIsBypassingPrompt = NO;
            });
            [self deactivate];
        }]];
    }

    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        [self deactivate];
    }]];
}

- (BOOL)shouldShowInLockScreen { return NO; }
- (BOOL)dismissOnLock { return YES; }

%end

%hook SBUIController

- (void)activateApplication:(SBApplication *)app {
    if (!CraneIsEnabled() || gIsBypassingPrompt) {
        %orig;
        return;
    }

    NSString *bundleID = nil;
    if ([app respondsToSelector:@selector(bundleIdentifier)]) {
        bundleID = [app bundleIdentifier];
    }

    if (bundleID && ![bundleID hasPrefix:@"com.apple."]) {
        BOOL alwaysAsk = CraneGetAppBool(bundleID, @"PromptOnLaunch", NO);
        if (alwaysAsk) {
            NSArray *containers = CraneGetContainersForBundle(bundleID);
            if (containers.count > 1) {
                // 通过动态类名获取已注册的子类
                CraneLaunchPromptAlertItem *alertItem = [[%c(CraneLaunchPromptAlertItem) alloc] init];
                alertItem.targetBundleID = bundleID;
                alertItem.targetContainers = containers;
                [[%c(SBAlertItemsController) sharedInstance] activateAlertItem:alertItem];
                return;
            }
        }
    }

    %orig;
}

%end

%hook UIWebClip

- (void)launch {
    NSURL *url = [self pageURL];
    if ([[url scheme] isEqualToString:CRANE_SCHEME]) {
        NSURLComponents *comp = [NSURLComponents componentsWithURL:url resolvingAgainstBaseURL:NO];
        NSString *targetBundle = nil;
        NSString *targetContainer = nil;
        for (NSURLQueryItem *item in comp.queryItems) {
            if ([item.name isEqualToString:@"bundleID"]) targetBundle = item.value;
            if ([item.name isEqualToString:@"container"]) targetContainer = item.value;
        }
        if (targetBundle && targetContainer) {
            CraneSetActiveContainerForBundle(targetBundle, targetContainer);
            KillProcess(targetBundle);
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                LaunchTargetApp(targetBundle);
            });
            return;
        }
    }
    %orig;
}

%end

%hook SBApplicationShortcutStore

- (NSArray *)shortcutItems {
    if (!CraneIsEnabled()) return %orig;

    NSArray *orig = %orig;
    NSString *bundleID = [self bundleIdentifier];
    if (!bundleID || [bundleID hasPrefix:@"com.apple."]) return orig;

    NSMutableArray *items = [orig mutableCopy] ?: [NSMutableArray array];
    NSString *activeContainer = CraneActiveContainerForBundle(bundleID);
    NSArray *containers = CraneGetContainersForBundle(bundleID);

    for (NSString *cID in containers) {
        SBSApplicationShortcutItem *switchItem = [[%c(SBSApplicationShortcutItem) alloc] init];
        switchItem.type = [NSString stringWithFormat:@"com.crane.switch.%@", cID];
        switchItem.localizedTitle = [NSString stringWithFormat:@"切换至: %@", cID];
        switchItem.localizedSubtitle = [cID isEqualToString:activeContainer] ? @"[当前激活]" : @"点击切换激活容器";
        [items addObject:switchItem];
    }
    return items;
}

%end

%hook SpringBoard

- (void)applicationShortcutStore:(id)store activateShortcutItem:(SBSApplicationShortcutItem *)item forBundleIdentifier:(NSString *)bundleIdentifier {
    if ([item.type hasPrefix:@"com.crane.switch."]) {
        NSString *cID = [item.type stringByReplacingOccurrencesOfString:@"com.crane.switch." withString:@""];
        CraneSetActiveContainerForBundle(bundleIdentifier, cID);
        KillProcess(bundleIdentifier);
    }
    %orig;
}

%end

%ctor {
    @autoreleasepool {
        %init;
        CleanCorruptedWebClips();
        int token;
        notify_register_dispatch(NOTIFY_CREATE_CLIP, &token, dispatch_get_main_queue(), ^(int t) {
            HandleClipCreationRequest();
        });
    }
}

#pragma clang diagnostic pop
