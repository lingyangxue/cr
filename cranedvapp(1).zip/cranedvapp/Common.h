#pragma once
#import <Foundation/Foundation.h>
#import <sys/stat.h>

#define PREF_DOMAIN CFSTR("com.developer.craneadvanced")
#define PREF_PATH @"/var/mobile/Library/Preferences/com.developer.craneadvanced.plist"
#define CRANE_SCHEME @"crane-launch"
#define NOTIFY_CREATE_CLIP "com.developer.craneadvanced.createclip"

// 从文件直接读取配置，避开沙盒缓存丢失
static inline NSMutableDictionary *CraneLoadAllPrefs(void) {
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:PREF_PATH];
    return dict ? [dict mutableCopy] : [NSMutableDictionary dictionary];
}

// 物理落盘并同步至全局 cfprefsd
static inline void CraneSaveAllPrefs(NSDictionary *dict) {
    if (!dict) return;
    [dict writeToFile:PREF_PATH atomically:YES];
    chmod([PREF_PATH UTF8String], 0666);

    for (NSString *key in dict) {
        id val = dict[key];
        CFPreferencesSetValue((__bridge CFStringRef)key,
                              (__bridge CFPropertyListRef)val,
                              PREF_DOMAIN,
                              kCFPreferencesCurrentUser,
                              kCFPreferencesAnyHost);
    }
    CFPreferencesSynchronize(PREF_DOMAIN, kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
}

static inline BOOL CraneIsEnabled(void) {
    NSDictionary *prefs = CraneLoadAllPrefs();
    if (prefs[@"Enabled"] == nil) return YES;
    return [prefs[@"Enabled"] boolValue];
}

static inline NSString *CraneActiveContainerForBundle(NSString *bundleID) {
    if (!bundleID) return @"default";
    NSDictionary *prefs = CraneLoadAllPrefs();
    NSString *val = prefs[bundleID];
    return (val && val.length > 0) ? val : @"default";
}

static inline void CraneSetActiveContainerForBundle(NSString *bundleID, NSString *containerID) {
    if (!bundleID || !containerID) return;
    NSMutableDictionary *prefs = CraneLoadAllPrefs();
    prefs[bundleID] = containerID;
    CraneSaveAllPrefs(prefs);
}

static inline NSArray *CraneGetContainersForBundle(NSString *bundleID) {
    if (!bundleID) return @[@"default"];
    NSDictionary *prefs = CraneLoadAllPrefs();
    NSString *key = [NSString stringWithFormat:@"Containers_%@", bundleID];
    NSArray *list = prefs[key];
    return (list && list.count > 0) ? list : @[@"default"];
}

static inline BOOL CraneGetAppBool(NSString *bundleID, NSString *key, BOOL defaultVal) {
    NSDictionary *prefs = CraneLoadAllPrefs();
    NSString *fullKey = [NSString stringWithFormat:@"%@_%@", bundleID, key];
    if (prefs[fullKey] == nil) return defaultVal;
    return [prefs[fullKey] boolValue];
}

static inline void CraneSetAppBool(NSString *bundleID, NSString *key, BOOL val) {
    NSMutableDictionary *prefs = CraneLoadAllPrefs();
    NSString *fullKey = [NSString stringWithFormat:@"%@_%@", bundleID, key];
    prefs[fullKey] = @(val);
    CraneSaveAllPrefs(prefs);
}
